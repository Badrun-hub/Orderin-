```markdown
# Design System Strategy: The Culinary Architect

This document outlines the visual language and structural logic for our restaurant management ecosystem. We are moving away from the "generic SaaS" aesthetic of boxes and lines. Instead, we are building a "Digital Atelier"—an environment that feels as intentional and curated as a high-end kitchen.

## 1. Creative North Star: "Precision Hospitality"
Our design philosophy is **Precision Hospitality**. In a restaurant, luxury is found in the absence of friction and the presence of quiet confidence. This design system mirrors that through an editorial layout style. We reject the "dashboard clutter" of traditional POS systems in favor of asymmetric breathing room, tonal depth, and a hierarchy that guides the eye like a well-composed menu. 

The interface should feel like a series of physical layers—stacked sheets of frosted glass and premium paper—rather than a flat digital screen.

---

## 2. Color & Atmosphere
We utilize a sophisticated palette that balances the organic warmth of Emerald Green with a deep, cinematic dark mode for administrative tasks and a crisp, airy light mode for customers.

### The "No-Line" Rule
**Lines are a failure of hierarchy.** In this system, 1px solid borders are prohibited for sectioning. Boundaries must be defined solely through background color shifts or subtle tonal transitions. 
*   *Implementation:* Use `surface-container-low` for your main background and `surface-container-high` for interactive elements.

### Surface Hierarchy & Nesting
Think of the UI as a series of nested trays. 
- **Base Level:** `surface` (#091421)
- **Primary Workspaces:** `surface-container` (#16202e)
- **Active Cards/Modals:** `surface-container-highest` (#2b3544)

### The Glass & Gradient Rule
To inject "soul" into the efficiency:
- **Hero Actions:** Use a subtle linear gradient from `primary` (#4edea3) to `primary_container` (#10b981).
- **Floating Elements:** Use Glassmorphism. Apply `surface_variant` at 60% opacity with a `20px` backdrop-blur to allow underlying colors to bleed through, creating an integrated, premium feel.

---

## 3. Typography: The Editorial Voice
We use a dual-font strategy to balance character with utility.

- **The Display Voice (Manrope):** Used for `display` and `headline` scales. Its geometric yet warm curves provide the "Signature" feel of a high-end brand.
- **The Functional Voice (Inter):** Used for `title`, `body`, and `label` scales. Inter provides the rigorous legibility required for fast-paced kitchen and billing environments.

**Hierarchy as Direction:**
- **Emphasis:** Use `display-md` for high-level metrics (e.g., total daily revenue) to give them a "hero" presence.
- **Micro-Copy:** Use `label-sm` in all-caps with `0.05em` letter-spacing for category headers to create an organized, architectural feel.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are often messy. We use **Tonal Layering** and **Ambient Light**.

- **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. The delta in luminance creates a natural "lift" without the need for heavy shadows.
- **Ambient Shadows:** For high-priority floating elements (like a "New Order" notification), use:
  - `box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12), 0 0 0 1px rgba(187, 202, 191, 0.05);`
  - The second shadow is a **Ghost Border**—a 5% opacity stroke that mimics the way light catches the edge of a glass pane.
- **Interactive Depth:** On hover, an element should move from `surface-container-high` to `surface-container-highest` rather than just changing color.

---

## 5. Signature Components

### Buttons & CTAs
- **Primary:** Gradient fill (`primary` to `primary_container`), `8px` (DEFAULT) roundedness, and `title-sm` typography. 
- **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
- **Tertiary:** Transparent background with `primary` text. Use only for low-emphasis utility actions.

### Cards & Lists (The "No Divider" Mandate)
- **Prohibition:** Do not use horizontal lines to separate menu items or orders.
- **Solution:** Use vertical white space from our spacing scale (e.g., `1.5rem` between items) and subtle `surface-container` shifts. This keeps the UI "breathable."
- **Contextual Status:** Use a vertical "Intent Bar" (4px wide) on the far left of a card using `tertiary` (Amber) for new orders or `error` (Rose) for payment pending.

### The "Order Flow" Chip
- Used for tracking food status. Use `secondary_container` for the background and `on_secondary_container` for the text. The contrast should be soft, not jarring, to reduce cognitive load during a busy shift.

### Input Fields
- **Default State:** `surface-container-highest` background. No border.
- **Focus State:** `0 0 0 2px surface_tint`. The field should feel like it's "lighting up" from within.

---

## 6. Do’s and Don’ts

### Do:
- **Do** embrace white space. If a screen feels crowded, increase the spacing between containers rather than adding lines.
- **Do** use `manrope` for numbers. In a restaurant app, numbers (prices, table IDs) are data-points that deserve editorial styling.
- **Do** use glassmorphism for top navigation bars to allow the scrollable content to peek through, maintaining a sense of place.

### Don’t:
- **Don't** use pure black (#000000). Use our `surface` (#091421) for a deeper, more professional tonal range.
- **Don't** use high-contrast borders. If you feel a border is needed, your background colors aren't doing their job.
- **Don't** use standard "Success Green" for everything. Reserve `forest green` for finality (Delivered) and use `emerald` for active service states.

---

## 7. Accessibility Note
While we prioritize aesthetics, the "Ghost Border" and Tonal Layering must maintain a minimum contrast ratio of 3:1 for structural elements and 4.5:1 for text. When in doubt, lean on the `on-surface-variant` color for supporting text to ensure it remains legible under harsh kitchen lighting.```