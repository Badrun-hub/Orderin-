import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { supabase } from '../../lib/supabase'
import { formatRupiah } from '../../utils/formatRupiah'
import { useSettingsStore } from '../../store/settingsStore'

export default function DashboardAdmin() {
  const navigate = useNavigate()
  const { user, logout } = useAuthStore()
  const { cafeName, cafeLogo } = useSettingsStore()
  
  const [stats, setStats] = useState({
    totalRevenue: 0, 
    totalOrders: 0,
    activeTables: 0,
    totalTables: 0
  })

  const [weeklyData, setWeeklyData] = useState([])
  const [topMenus, setTopMenus] = useState([])

  // Realtime Supabase Data Fetching
  useEffect(() => {
    const fetchStats = async () => {
      try {
        // Fetch Tables
        const { data: tableData } = await supabase.from('tables').select('*')
        const t = tableData || []
        const activeT = t.filter(x => x.status !== 'available' && x.status !== 'kosong').length

        // Fetch Orders for Today & 7 Days
        const { data: orderData } = await supabase.from('orders').select('*, order_items(*)')
        const ords = orderData || []

        const startOfDay = new Date()
        startOfDay.setHours(0,0,0,0)

        // Today's Orders
        const todaysOrders = ords.filter(o => new Date(o.created_at) >= startOfDay)
        const revenue = todaysOrders.filter(o => o.status === 'selesai' || o.status === 'paid' || o.status === 'delivered')
                                    .reduce((sum, o) => sum + (o.total || 0), 0)

        setStats({
          totalRevenue: revenue,
          totalOrders: todaysOrders.length,
          activeTables: activeT,
          totalTables: t.length
        })

        // Chart 7 Days
        const days = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN']
        let weekly = days.map(d => ({ day: d, orders: 0 }))
        
        let menuCount = {}

        ords.filter(o => o.status === 'selesai' || o.status === 'paid' || o.status === 'delivered')
            .forEach(ord => {
              // Day distribution
              const d = new Date(ord.created_at)
              let dayIdx = d.getDay() - 1
              if (dayIdx === -1) dayIdx = 6 // Sunday is last
              weekly[dayIdx].orders += 1

              // Menus distribution
              if (ord.order_items) {
                 ord.order_items.forEach(item => {
                    menuCount[item.nama_menu] = (menuCount[item.nama_menu] || 0) + item.qty
                 })
              }
            })

        // Top 4 Menus
        const sortedMenus = Object.keys(menuCount)
          .map(name => ({ name, val: menuCount[name] }))
          .sort((a,b) => b.val - a.val)
          .slice(0, 4)
        
        const totalItemsSold = sortedMenus.reduce((sum, m) => sum + m.val, 0)
        // Convert to percentage strings
        const topCalculated = sortedMenus.map(m => ({
           name: m.name.substring(0, 15) + (m.name.length > 15 ? '...' : ''),
           val: totalItemsSold > 0 ? Math.round((m.val / totalItemsSold) * 100) + '%' : '0%'
        }))

        // Normalize weekly orders to percentage (height)
        const maxOrder = Math.max(...weekly.map(w => w.orders), 1)
        const weeklyNormalized = weekly.map((w, idx) => ({
          day: w.day,
          height: Math.max((w.orders / maxOrder) * 100, 5) + '%',
          isToday: idx === (new Date().getDay() - 1 === -1 ? 6 : new Date().getDay() - 1),
          orders: w.orders
        }))

        setWeeklyData(weeklyNormalized)
        setTopMenus(topCalculated)

      } catch (err) {
        console.error("Gagal memuat stats admin:", err)
      }
    }

    fetchStats()

    // Subscribe Realtime Setup
    const channel = supabase.channel('admin_dashboard')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, fetchStats)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tables' }, fetchStats)
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  if (!user || user.role !== 'admin') {
    return (
      <div className="bg-surface text-on-surface min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <span className="material-symbols-outlined text-error text-6xl mb-4">lock</span>
          <h2 className="text-xl font-bold font-headline mb-2">Akses Terlarang</h2>
          <p className="text-sm text-on-surface-variant mb-6">Halaman ini khusus untuk manajemen tinggi.</p>
          <button onClick={() => navigate('/admin/login')} className="bg-primary text-on-primary px-6 py-3 rounded-xl font-bold">
            Portal Admin
          </button>
        </div>
      </div>
    )
  }

  return (
    <>
      <div className="flex flex-col gap-1 mb-8">
        <div className="flex items-center gap-3">
          <h1 className="text-4xl font-extrabold tracking-tight font-headline">Admin Dashboard</h1>
          <span className="px-2 py-0.5 bg-primary/20 text-primary text-[10px] font-bold rounded flex items-center gap-1 uppercase tracking-wider animate-pulse border border-primary/30">
            <span className="w-1.5 h-1.5 bg-primary rounded-full"></span> Realtime
          </span>
        </div>
        <p className="text-on-surface-variant text-sm font-medium opacity-80 uppercase tracking-widest">Pemantauan otomatis & sentralisasi data (LIVE)</p>
      </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
             <div onClick={() => navigate('/admin/menu')} className="bg-surface-container rounded-[2rem] p-6 flex flex-col items-center justify-center text-center gap-3 cursor-pointer hover:bg-surface-container-high hover:scale-[1.02] active:scale-95 transition-all shadow-lg hover:shadow-primary/5 group">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-1 group-hover:bg-primary/20 transition-colors">
                  <span className="material-symbols-outlined text-primary text-2xl font-bold">menu_book</span>
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant group-hover:text-primary transition-colors">Kelola Menu</p>
             </div>
             <div onClick={() => navigate('/admin/meja')} className="bg-surface-container rounded-[2rem] p-6 flex flex-col items-center justify-center text-center gap-3 cursor-pointer hover:bg-surface-container-high hover:scale-[1.02] active:scale-95 transition-all shadow-lg hover:shadow-secondary/5 group">
                <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center mb-1 group-hover:bg-secondary/20 transition-colors">
                  <span className="material-symbols-outlined text-secondary text-2xl font-bold">table_restaurant</span>
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant group-hover:text-secondary transition-colors">Meja & QR</p>
             </div>
             <div onClick={() => navigate('/admin/kasir')} className="bg-surface-container rounded-[2rem] p-6 flex flex-col items-center justify-center text-center gap-3 cursor-pointer hover:bg-surface-container-high hover:scale-[1.02] active:scale-95 transition-all shadow-lg hover:shadow-tertiary/5 group">
                <div className="w-12 h-12 rounded-2xl bg-tertiary/10 flex items-center justify-center mb-1 group-hover:bg-tertiary/20 transition-colors">
                  <span className="material-symbols-outlined text-tertiary text-2xl font-bold">badge</span>
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant group-hover:text-tertiary transition-colors">Staf Kasir</p>
             </div>
             <div onClick={() => navigate('/admin/analytics')} className="bg-surface-container rounded-[2rem] p-6 flex flex-col items-center justify-center text-center gap-3 cursor-pointer hover:bg-surface-container-high hover:scale-[1.02] active:scale-95 transition-all shadow-lg hover:shadow-blue-500/5 group">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/10 flex items-center justify-center mb-1 group-hover:bg-blue-500/20 transition-colors">
                  <span className="material-symbols-outlined text-blue-500 text-2xl font-bold">monitoring</span>
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant group-hover:text-blue-500 transition-colors">Analytics</p>
             </div>
          </div>

          {/* Data Realtime Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-surface-container rounded-2xl p-6 relative overflow-hidden group hover:bg-surface-container-high transition-all shadow-[0_20px_40px_rgba(0,0,0,0.12)]">
              <div className="absolute top-0 left-0 w-1 h-full bg-primary-container"></div>
              <div className="flex justify-between items-start mb-4">
                <span className="material-symbols-outlined text-primary bg-primary/10 p-2 rounded-lg">payments</span>
              </div>
              <p className="text-on-surface-variant text-xs uppercase tracking-widest font-bold mb-1">Total Pendapatan (Hari Ini)</p>
              <h2 className="text-4xl font-extrabold font-headline tracking-tighter">{formatRupiah(stats.totalRevenue)}</h2>
            </div>
            
            <div className="bg-surface-container rounded-2xl p-6 relative overflow-hidden group hover:bg-surface-container-high transition-all shadow-[0_20px_40px_rgba(0,0,0,0.12)]">
              <div className="absolute top-0 left-0 w-1 h-full bg-secondary-container"></div>
              <div className="flex justify-between items-start mb-4">
                <span className="material-symbols-outlined text-secondary bg-secondary/10 p-2 rounded-lg">shopping_bag</span>
              </div>
              <p className="text-on-surface-variant text-xs uppercase tracking-widest font-bold mb-1">Pesanan (Hari Ini)</p>
              <h2 className="text-4xl font-extrabold font-headline tracking-tighter">{stats.totalOrders} Transaksi</h2>
            </div>

            <div className="bg-surface-container rounded-2xl p-6 relative overflow-hidden group hover:bg-surface-container-high transition-all shadow-[0_20px_40px_rgba(0,0,0,0.12)]">
              <div className="absolute top-0 left-0 w-1 h-full bg-tertiary-container"></div>
              <div className="flex justify-between items-start mb-4">
                <span className="material-symbols-outlined text-tertiary bg-tertiary/10 p-2 rounded-lg">sensor_occupied</span>
              </div>
              <p className="text-on-surface-variant text-xs uppercase tracking-widest font-bold mb-1">Kapasitas Penuh</p>
              <h2 className="text-4xl font-extrabold font-headline tracking-tighter">
                {stats.activeTables}<span className="text-slate-500 text-2xl font-medium"> / {stats.totalTables} Meja</span>
              </h2>
            </div>
          </div>

          {/* Charts Live */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-4">
            
            {/* Weekly Orders DB */}
            <div className="bg-surface-container rounded-3xl p-8 shadow-xl shadow-black/5">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-xl font-bold font-headline">Pesanan Seminggu</h3>
                  <p className="text-xs text-on-surface-variant font-medium uppercase tracking-widest opacity-60">Volume transaksi 7 hari terakhir</p>
                </div>
              </div>
              <div className="flex items-end justify-between h-48 gap-2 pt-4">
                {weeklyData.map((d) => (
                  <div key={d.day} className="flex flex-col items-center gap-2 w-full group relative">
                    <span className="opacity-0 group-hover:opacity-100 absolute -top-8 text-[10px] font-black text-on-primary bg-primary px-2 py-1 rounded transition-all shadow-lg">{d.orders}</span>
                    <div className={`w-full ${d.isToday ? 'bg-primary shadow-[0_10px_20px_rgba(var(--theme-primary-rgb),0.3)]' : 'bg-surface-container-highest group-hover:bg-primary/50'} rounded-t-xl transition-all duration-300`} style={{height: d.height}}></div>
                    <span className={`text-[10px] font-black tracking-tighter ${d.isToday ? 'text-primary' : 'text-on-surface-variant'}`}>{d.day}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Selling Menus DB */}
            <div className="bg-surface-container rounded-3xl p-8 shadow-xl shadow-black/5">
              <h3 className="text-xl font-bold mb-1 font-headline">Menu Terlaris</h3>
              <p className="text-xs text-on-surface-variant font-medium mb-8 uppercase tracking-widest opacity-60">Data asli berdasarkan order masuk</p>
              <div className="flex flex-col gap-6">
                {topMenus.length > 0 ? topMenus.map((cat, i) => (
                  <div key={i} className="space-y-3">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                      <span className="text-on-surface-variant">{cat.name}</span>
                      <span className="text-primary">{cat.val}</span>
                    </div>
                    <div className="h-2.5 w-full bg-surface-container-highest rounded-full overflow-hidden shadow-inner">
                      <div className="h-full bg-primary transition-all duration-1000 ease-out" style={{width: cat.val}}></div>
                    </div>
                  </div>
                )) : (
                  <div className="text-center text-sm text-on-surface-variant py-6 font-medium">Belum ada item terjual.</div>
                )}
              </div>
            </div>

          </div>

    </>
  )
}
